package com.example.Configuration.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigurationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
